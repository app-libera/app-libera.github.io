<?php

if ( !defined( 'ABSPATH' ) ) exit;

/*
 * Function that generates an entry in the Administration menu
 */
function liberachat_plugin_menu() {
    add_menu_page('Configuring LiberaChat', //Page title 
        'LiberaChat',                       //Menu title 
        'administrator',                         //Role with permissions 
        'liberachat_info',                   //Page id 
        'liberachat_settingspage',           //Playback function
        plugins_url('app-liberachat/img/liberachat.png'), //Icon
        61                                      //Position
        );

     add_submenu_page('liberachat_info',
        'Configuracion',
        'Info',
        'administrator',                     //Role with permissions 
        'liberachat_info',               //Page id
        'liberachat_settingspage');      //Playback function 

     add_submenu_page('liberachat_info',
        'Configuracion',
        'Settings',
        'administrator',                      //Role with permissions
        'libera-chat-settings',           //Page id
        'libera_chat_settingspage');    //Playback function 

}

add_action('admin_menu', 'liberachat_plugin_menu');

/*
 * Function that records values in the internal DB
 */
function liberachat_info() {
	
    register_setting('liberachat-reg',
                     'liberachat_nick');
    register_setting('liberachat-reg',
                     'liberachat_server');
    register_setting('liberachat-reg',
                     'liberachat_chan');
    register_setting('liberachat-reg',
                     'liberachat_style');
    register_setting('liberachat-reg',
                     'liberachat_height');
    register_setting('liberachat-reg',
                     'liberachat_width');				 				 
}

add_action('admin_init', 'liberachat_info');


/*
 * Function that plays the main configuration page
 */
function liberachat_settingspage() {
    // check user capabilities
    if (!current_user_can('manage_options')) {
        return;
    }
?>

    <div class="wrap">
        <h2>LiberaChat WordPress Plugin</h2>
        <p>LiberaChat is an online chat client, your IRC client based on <a href="https://libera.chat" target="_blank" title="Libera.Chat">Libera.Chat</a></p>
        <div class="card pressthis">
            <h3>Instructions for use</h3>
            <p>Place shortcode in your pages or posts:</p>
			<h4>[kiwi_liberachat]</h4>
            <p>You can specify channel for a specific page instead of using the default channel configured with:</p>
            <h4>[kiwi_liberachat chan=#YourChannel]</h4>
            <br/>
        </div>
	   <div class="card pressthis">
		<h3>Configuring LiberaChata</h3> <h4><a href="admin.php?page=libera-chat-settings" title="Settings">Settings</a></h4>
		 <p>For more documentation on usage and configuration 
		 <a href="https://app-libera.github.io" target="_blank" title="Documentation">Click Here</a></p>
        <br/>
       </div>
    </div>
<?php
}


/*
 * Function that plays the main configuration page
 */
function libera_chat_settingspage() {
    // check user capabilities
    if (!current_user_can('manage_options')) {
        return;
    }

    //Error message 
    if (isset($_GET['settings-updated'])) {
        add_settings_error('libera_messages', 'libera_message_ok', ('Updated values'), 'updated');
    }
    if (isset($_GET['settings-error'])) {
        add_settings_error('libera_messages', 'libera_message_error', ('A save error occurred'), 'error');
    }

    settings_errors('libera_messages');
?>

     <div class="wrap">
	 
        <h1>Configuring LiberaChat</h1>
  
        <form method="POST" action="options.php">
            <?php
                settings_fields('liberachat-reg');
                do_settings_sections('liberachat-reg');
            ?>
<table width="100%" border="0">
   
   <tr>
     <td><strong><?php _e("Connected from:" ); ?></strong></td>
     <td><input type="text" id="liberachat_server" name="liberachat_server" value="https://web.libera.chat"disabled="1" size="25"></td>
     <td><em><a href="https://libera.chat" target="_blank" title="Libera.Chat">Libera.Chat</a> the IRC network for free & open source software</em></td>
  </tr>
	   
		<tr>
    <td><strong><?php _e("Nickname Suggestion:" ); ?></strong></td>
    <td><input type="text" id="liberachat_nick" name="liberachat_nick" value="<?php echo get_option('liberachat_nick'); ?>" size="25"></td>
    <td><em>Default nickname for your chatroom's LiberaChat. (Default is Guest?) [? is replaced with 3 random numbers]</em></td>
  </tr>
  
    <tr>
    <td><strong><?php _e("Channel:" ); ?></strong></td>
    <td><input type="text" name="liberachat_chan"  value="<?php echo get_option('liberachat_chan'); ?>" size="25"></td>
    <td><em>The name of your chatroom. (Default is #Libera)</em></td>
  </tr>
						
  <tr>
    <td><strong><?php _e("LiberaChat Theme:" ); ?></strong></td>
    <td><select name="liberachat_style"
	            id="liberachat_style">
			   <option value="default" <?php selected(get_option('liberachat_style'), "default"); ?>>Default</option>
			   <option value="osprey" <?php selected(get_option('liberachat_style'), "osprey"); ?>>Osprey</option>
			   <option value="radioactive" <?php selected(get_option('liberachat_style'), "radioactive"); ?>>Radioactive</option>
	           <option value="dark" <?php selected(get_option('liberachat_style'), "dark"); ?>>Dark</option>
               <option value="nightswatch" <?php selected(get_option('liberachat_style'), "nightswatch"); ?>>Nightswatch</option>
               <option value="sky" <?php selected(get_option('liberachat_style'), "sky"); ?>>Sky</option>
			   <option value="coffee" <?php selected(get_option('liberachat_style'), "coffee"); ?>>Coffee</option>
			   <option value="grayfox" <?php selected(get_option('liberachat_style'), "grayfox"); ?>>GrayFox</option>
        </select>
    <td><em>Color style of the chatroom. (Default is Osprey)</em></td>
  </tr>
<tr>
    <td><strong><?php _e("Width:" ); ?></strong></td>
    <td><input type="text" 
	name="liberachat_width"
	id="liberachat_width"
	value="<?php echo get_option('liberachat_width'); ?>" size="8"></td>
    <td><em>Width of your chatroom. (Default is 100%)</em></td>
  </tr>
  
  <tr>
    <td><strong><?php _e("Height:" ); ?></strong></td>
    <td><input type="text"
	name="liberachat_height"
	id="liberachat_height"
    value="<?php echo get_option('liberachat_height'); ?>" size="8"></td>
    <td><em>Height of your chatroom. (Default is 500)</em></td>
  </tr>
<br/>	
</table>		
        <p style="font-weight: bold;">
		NOTE: Users' preferences will always have priority over this configuration. For example, if a user configures that a particular nickname is used and a particular channel is accessed, then that configuration will always have priority over that of that configuration, so it will enter the channel specified in the configuration.</p>
            <?php submit_button(); ?>
        </form>
    </div>


<?php
}
?>
